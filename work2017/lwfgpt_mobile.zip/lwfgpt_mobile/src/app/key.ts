export class Key {
  url: string;
  key: string;
  key2:string;
}
export const KEY: Key = {
  //url: 'http://zhikuyun.lwinst.com/',
   url: 'http://testliaowang.chengjuiot.com/',
  key2:'',
  key: '6135fde33661106c0c1821b07bd7639d'
}
